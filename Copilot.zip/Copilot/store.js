// Simple in-memory store. Resets on page refresh.

const Store = (function () {
  const ROLES = ["admin", "educator", "sp", "COR"];
  const MODULES = ["A", "B", "C", "D", "E", "F"];

  const users = [];

  function generatePasscode() {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*";
    const length = Math.floor(Math.random() * 6) + 1; // 1–6 chars
    let code = "";
    for (let i = 0; i < length; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
  }

  // Predefined master admin
  const masterAdmin = {
    id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()),
    role: "admin",
    firstName: "Master",
    lastName: "Admin",
    email: "master.admin@example.com",
    passcode: generatePasscode(),
    modules: [...MODULES],
    active: true
  };
  users.push(masterAdmin);

  function getModules() {
    return [...MODULES];
  }

  function getRoles() {
    return [...ROLES];
  }

  function getAllUsers() {
    return users.slice();
  }

  function getUserByPasscode(passcode) {
    return users.find(u => u.active && u.passcode === passcode) || null;
  }

  function createUser({ role, firstName, lastName, email, modules }) {
    const id = crypto.randomUUID ? crypto.randomUUID() : String(Date.now() + Math.random());
    const passcode = generatePasscode();
    const user = {
      id,
      role,
      firstName,
      lastName,
      email,
      passcode,
      modules: Array.isArray(modules) ? modules.slice() : [],
      active: true
    };
    users.push(user);
    return user;
  }

  function updateUser(id, updates) {
    const user = users.find(u => u.id === id);
    if (!user) return null;
    if (typeof updates.role === "string" && ROLES.includes(updates.role)) {
      user.role = updates.role;
    }
    if (Array.isArray(updates.modules)) {
      user.modules = updates.modules.filter(m => MODULES.includes(m));
    }
    if (typeof updates.firstName === "string") user.firstName = updates.firstName;
    if (typeof updates.lastName === "string") user.lastName = updates.lastName;
    if (typeof updates.email === "string") user.email = updates.email;
    if (typeof updates.active === "boolean") user.active = updates.active;
    return user;
  }

  function deleteUser(id) {
    const idx = users.findIndex(u => u.id === id);
    if (idx >= 0) {
      users.splice(idx, 1);
      return true;
    }
    return false;
  }

  function getUserLogByRole() {
    const log = {};
    ROLES.forEach(r => (log[r] = []));
    users.forEach(u => {
      if (!log[u.role]) log[u.role] = [];
      log[u.role].push({
        id: u.id,
        name: `${u.firstName} ${u.lastName}`,
        email: u.email,
        passcode: u.passcode,
        modules: u.modules.slice(),
        active: u.active
      });
    });
    return log;
  }

  return {
    getModules,
    getRoles,
    getAllUsers,
    getUserByPasscode,
    createUser,
    updateUser,
    deleteUser,
    getUserLogByRole,
    masterAdmin
  };
})();
