const Router = (function () {
  const app = document.getElementById("app");
  let currentUser = null;

  const routes = {
    login: { view: "views/login.html" },
    dashboard: { view: "views/dashboard.html" },
    accessDenied: { view: "views/access-denied.html" },
    module: name => ({ view: `modules/module${name}.html` })
  };

  function setCurrentUser(user) {
    currentUser = user;
  }

  function getCurrentUser() {
    return currentUser;
  }

  function loadView(path, extra = {}) {
    return fetch(path)
      .then(res => res.text())
      .then(html => {
        app.innerHTML = html;
        afterViewLoad(extra);
      })
      .catch(() => {
        app.innerHTML = `<div class="card"><h2>View Error</h2><p>Unable to load view.</p></div>`;
      });
  }

  function navigateToLogin() {
    window.location.hash = "#/login";
  }

  function navigateToDashboard() {
    window.location.hash = "#/dashboard";
  }

  function navigateToModule(name) {
    window.location.hash = `#/module/${name}`;
  }

  function navigateToAccessDenied() {
    window.location.hash = "#/access-denied";
  }

  function handleHashChange() {
    const hash = window.location.hash || "#/login";
    const parts = hash.replace("#/", "").split("/");
    const route = parts[0];

    if (!currentUser && route !== "login") {
      return navigateToLogin();
    }

    if (route === "login") {
      return loadView(routes.login.view, { view: "login" });
    }

    if (route === "dashboard") {
      return loadView(routes.dashboard.view, { view: "dashboard" });
    }

    if (route === "module") {
      const moduleName = parts[1];
      if (!moduleName) return navigateToDashboard();
      if (!currentUser || !currentUser.modules.includes(moduleName)) {
        return loadView(routes.accessDenied.view, { view: "accessDenied" });
      }
      return loadView(routes.module(moduleName).view, {
        view: "module",
        moduleName
      });
    }

    if (route === "access-denied") {
      return loadView(routes.accessDenied.view, { view: "accessDenied" });
    }

    navigateToLogin();
  }

  function attachLoginHandlers() {
    const form = document.getElementById("login-form");
    const passInput = document.getElementById("passcode");
    const errorBox = document.getElementById("login-error");
    const masterInfo = document.getElementById("master-info");

    if (masterInfo) {
      masterInfo.textContent = `Master Admin Passcode (for testing): ${Store.masterAdmin.passcode}`;
    }

    if (!form) return;
    form.addEventListener("submit", e => {
      e.preventDefault();
      const passcode = passInput.value.trim();
      if (!passcode || passcode.length > 6) {
        errorBox.textContent = "Passcode is required and must be at most 6 characters.";
        errorBox.style.display = "block";
        return;
      }
      const user = Store.getUserByPasscode(passcode);
      if (!user) {
        errorBox.textContent = "Invalid passcode.";
        errorBox.style.display = "block";
        return;
      }
      errorBox.style.display = "none";
      setCurrentUser(user);
      navigateToDashboard();
    });
  }

  function renderNavbar() {
    const navContainer = document.getElementById("navbar-container");
    if (!navContainer || !currentUser) return;

    fetch("components/navbar.html")
      .then(res => res.text())
      .then(html => {
        navContainer.innerHTML = html;
        const userLabel = document.getElementById("nav-user-label");
        if (userLabel) {
          userLabel.textContent = `${currentUser.firstName} ${currentUser.lastName} (${currentUser.role})`;
        }

        const dashboardBtn = document.getElementById("nav-dashboard");
        const logoutBtn = document.getElementById("nav-logout");
        const moduleButtons = document.querySelectorAll("[data-module-link]");

        if (dashboardBtn) {
          dashboardBtn.addEventListener("click", () => navigateToDashboard());
        }
        if (logoutBtn) {
          logoutBtn.addEventListener("click", () => {
            setCurrentUser(null);
            navigateToLogin();
          });
        }
        moduleButtons.forEach(btn => {
          const mod = btn.getAttribute("data-module-link");
          if (!currentUser.modules.includes(mod)) {
            btn.disabled = true;
          } else {
            btn.addEventListener("click", () => navigateToModule(mod));
          }
        });
      })
      .catch(() => {
        navContainer.innerHTML = "";
      });
  }

  function attachDashboardHandlers() {
    renderNavbar();

    const isAdmin = currentUser && currentUser.role === "admin";

    const adminSection = document.getElementById("admin-section");
    const userSection = document.getElementById("user-section");

    if (adminSection) adminSection.style.display = isAdmin ? "block" : "none";
    if (userSection) userSection.style.display = !isAdmin ? "block" : "none";

    if (isAdmin) {
      renderUserTable();
      renderModuleOverview();
      attachCreateUserForm();
    } else {
      renderUserModulesForNonAdmin();
    }
  }

  function attachCreateUserForm() {
    const form = document.getElementById("create-user-form");
    if (!form) return;

    const roleSelect = document.getElementById("new-role");
    const firstNameInput = document.getElementById("new-first-name");
    const lastNameInput = document.getElementById("new-last-name");
    const emailInput = document.getElementById("new-email");
    const modulesCheckboxes = document.querySelectorAll("[data-new-module]");
    const infoBox = document.getElementById("create-user-info");

    form.addEventListener("submit", e => {
      e.preventDefault();
      const role = roleSelect.value;
      const firstName = firstNameInput.value.trim();
      const lastName = lastNameInput.value.trim();
      const email = emailInput.value.trim();
      const modules = [];
      modulesCheckboxes.forEach(cb => {
        if (cb.checked) modules.push(cb.value);
      });

      if (!firstName || !lastName || !email) {
        infoBox.textContent = "All fields are required.";
        infoBox.className = "alert error";
        infoBox.style.display = "block";
        return;
      }

      const user = Store.createUser({ role, firstName, lastName, email, modules });
      infoBox.textContent = `User created. Passcode: ${user.passcode}`;
      infoBox.className = "alert info";
      infoBox.style.display = "block";

      form.reset();
      renderUserTable();
      renderModuleOverview();
    });
  }

  function renderUserTable() {
    const container = document.getElementById("user-table-container");
    if (!container) return;

    fetch("components/user-table.html")
      .then(res => res.text())
      .then(html => {
        container.innerHTML = html;
        populateUserTable();
      })
      .catch(() => {
        container.innerHTML = "<p>Unable to load user table.</p>";
      });
  }

  function populateUserTable() {
    const tbody = document.getElementById("user-table-body");
    const filterSelect = document.getElementById("filter-role");
    if (!tbody || !filterSelect) return;

    const modules = Store.getModules();
    const users = Store.getAllUsers();

    function renderRows() {
      const filter = filterSelect.value;
      tbody.innerHTML = "";
      users
        .filter(u => (filter === "all" ? true : u.role === filter))
        .forEach(u => {
          const tr = document.createElement("tr");
          tr.dataset.userId = u.id;

          const roleBadgeClass =
            u.role === "admin"
              ? "admin"
              : u.role === "educator"
              ? "educator"
              : u.role === "sp"
              ? "sp"
              : "cor";

          tr.innerHTML = `
            <td>${u.firstName}</td>
            <td>${u.lastName}</td>
            <td>${u.email}</td>
            <td><span class="badge ${roleBadgeClass}">${u.role}</span></td>
            <td>${u.passcode}</td>
            <td>
              ${modules
                .map(
                  m => `
                <label style="display:inline-flex;align-items:center;gap:2px;font-size:11px;">
                  <input type="checkbox" data-module-toggle="${m}" ${u.modules.includes(m) ? "checked" : ""} />
                  ${m}
                </label>
              `
                )
                .join("<br/>")}
            </td>
            <td>
              <button class="danger" data-deactivate>${u.active ? "Deactivate" : "Activate"}</button>
            </td>
          `;
          tbody.appendChild(tr);
        });
    }

    renderRows();

    filterSelect.addEventListener("change", () => renderRows());

    tbody.addEventListener("change", e => {
      const cb = e.target;
      if (!cb.matches("[data-module-toggle]")) return;
      const tr = cb.closest("tr");
      const userId = tr.dataset.userId;
      const moduleName = cb.getAttribute("data-module-toggle");
      const user = Store.getAllUsers().find(u => u.id === userId);
      if (!user) return;
      const newModules = new Set(user.modules);
      if (cb.checked) newModules.add(moduleName);
      else newModules.delete(moduleName);
      Store.updateUser(userId, { modules: Array.from(newModules) });
      renderModuleOverview();
    });

    tbody.addEventListener("click", e => {
      const btn = e.target;
      if (!btn.matches("[data-deactivate]")) return;
      const tr = btn.closest("tr");
      const userId = tr.dataset.userId;
      const user = Store.getAllUsers().find(u => u.id === userId);
      if (!user) return;
      Store.updateUser(userId, { active: !user.active });
      renderUserTable();
      renderModuleOverview();
    });
  }

  function renderModuleOverview() {
    const container = document.getElementById("module-overview-container");
    if (!container) return;

    fetch("components/module-list.html")
      .then(res => res.text())
      .then(html => {
        container.innerHTML = html;
        populateModuleOverview();
      })
      .catch(() => {
        container.innerHTML = "<p>Unable to load module overview.</p>";
      });
  }

  function populateModuleOverview() {
    const listContainer = document.getElementById("module-overview-list");
    if (!listContainer) return;

    const modules = Store.getModules();
    const users = Store.getAllUsers();

    listContainer.innerHTML = "";
    modules.forEach(m => {
      const card = document.createElement("div");
      card.className = "module-card";
      const assigned = users.filter(u => u.modules.includes(m) && u.active);
      card.innerHTML = `
        <h4>Module ${m}</h4>
        <p>Active users with access: ${assigned.length}</p>
        <ul style="margin:0;padding-left:18px;font-size:12px;">
          ${assigned
            .map(
              u =>
                `<li>${u.firstName} ${u.lastName} (${u.role})</li>`
            )
            .join("") || "<li>None</li>"}
        </ul>
      `;
      listContainer.appendChild(card);
    });
  }

  function renderUserModulesForNonAdmin() {
    const container = document.getElementById("user-modules-container");
    if (!container || !currentUser) return;

    const modules = currentUser.modules;
    const allModules = Store.getModules();

    const grid = document.createElement("div");
    grid.className = "module-grid";

    allModules.forEach(m => {
      const card = document.createElement("div");
      card.className = "module-card";
      const hasAccess = modules.includes(m);
      card.innerHTML = `
        <h4>Module ${m}</h4>
        <p>${hasAccess ? "You have access to this module." : "You do not have access to this module."}</p>
        <button ${hasAccess ? "" : "disabled"} data-open-module="${m}">
          ${hasAccess ? "Open" : "No Access"}
        </button>
      `;
      grid.appendChild(card);
    });

    container.innerHTML = "";
    container.appendChild(grid);

    container.addEventListener("click", e => {
      const btn = e.target;
      if (!btn.matches("[data-open-module]")) return;
      const mod = btn.getAttribute("data-open-module");
      navigateToModule(mod);
    });
  }

  function afterViewLoad(extra) {
    switch (extra.view) {
      case "login":
        attachLoginHandlers();
        break;
      case "dashboard":
        attachDashboardHandlers();
        break;
      case "module":
        renderNavbar();
        break;
      case "accessDenied":
        renderNavbar();
        break;
    }
  }

  function init() {
    window.addEventListener("hashchange", handleHashChange);
    if (!window.location.hash) {
      navigateToLogin();
    } else {
      handleHashChange();
    }
  }

  return {
    init,
    navigateToLogin,
    navigateToDashboard,
    navigateToModule,
    navigateToAccessDenied,
    getCurrentUser
  };
})();

document.addEventListener("DOMContentLoaded", () => {
  Router.init();
});
